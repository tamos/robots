import numpy as np

class EKF(object):
    # Construct an EKF instance with the following set of variables
    #    mu:                 The initial mean vector
    #    Sigma:              The initial covariance matrix
    #    R:                  The process noise covariance
    #    Q:                  The measurement noise covariance
    def __init__(self, mu, Sigma, R, Q):
        self.mu = mu
        self.Sigma = Sigma
        self.R = R
        self.Q = Q


        # Your code goes here
        print "Please add code"


    def getMean(self):
        return self.mu


    def getCovariance(self):
        return self.Sigma


    def getVariances(self):
        return np.array([[self.Sigma[0,0],self.Sigma[1,1],self.Sigma[2,2]]])
        

    # Perform the prediction step to determine the mean and covariance
    # of the posterior belief given the current estimate for the mean
    # and covariance, the control data, and the process model
    #    u:                 The forward distance and change in heading
    def prediction(self,u):

        # Your code goes here
        print "Please add code"



    # Perform the measurement update step to compute the posterior
    # belief given the predictive posterior (mean and covariance) and
    # the measurement data
    #    z:                The squared distance to the sensor and the
    #                      robot's heading
    def update(self,z):
        
        # Your code goes here
        print "Please add code"
